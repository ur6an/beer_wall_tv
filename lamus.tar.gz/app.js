async function refreshBeers()
{
    try {

        const response = await fetch('index.php?api=1');

        const data = await response.json();


        updateClock(data.time);

        updateStatus(data.live);

        updateCards(data.beers);


    }
    catch(error){

        console.log(
            'Błąd odświeżania',
            error
        );

    }
}





function updateClock(time)
{
    const clock = document.querySelector('.clock-time');


    if(clock){

        clock.textContent = time;

    }
}





function updateStatus(live)
{
    const status = document.querySelector('.status');


    if(status){

        status.textContent =
            live
            ? 'LIVE'
            : 'CACHE';



        status.style.color =
            live
            ? '#00ff66'
            : '#ff9900';

    }
}







function updateCards(beers)
{

    const grid = document.querySelector('.grid');


    if(!grid){

        return;

    }



    grid.innerHTML = '';




    beers.forEach(beer => {



        grid.innerHTML += `


<div class="card">



    <div class="top">



        <div class="tap">

            ${beer.tap}

        </div>





        <div class="names">



            <div class="brewery">

                ${beer.brewery}

            </div>





            <div class="beer">

                ${beer.beer}

            </div>



        </div>







        <div class="brewery-logo">



            ${
                beer.logo
                ?
                `
                <img
                    src="${beer.logo}"
                    alt=""
                    onerror="this.style.display='none'"
                >
                `
                :
                ''
            }



        </div>



    </div>








    <div class="bottom">





        <div class="meta">



            ${
                beer.style
                ?
                `
                <span class="beer-style">

                    ${beer.style}

                </span>
                `
                :
                ''
            }





            ${
                beer.blg
                ?
                `
                <span>

                    BLG ${beer.blg}°

                </span>
                `
                :
                ''
            }






            ${
                beer.abv
                ?
                `
                <span>

                    ALK ${beer.abv}%

                </span>
                `
                :
                ''
            }





        </div>









        <div class="prices">





            ${
                beer.sizes && beer.sizes.length
                ?
                beer.sizes.map(size => `


                    <div class="price">


                        ${size.size}l

                        ${size.price} zł


                    </div>


                `).join('')
                :
                ''
            }






        </div>






    </div>






</div>



`;



    });



}






// pierwsze pobranie

refreshBeers();




// odświeżanie danych

setInterval(
    refreshBeers,
    120000
);
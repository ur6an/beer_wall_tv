<?php

declare(strict_types=1);


require_once 'functions.php';



$data = getBeers();



/*
=================================
API DLA APP.JS
=================================
*/

if(isset($_GET['api'])){


    header(
        'Content-Type: application/json; charset=utf-8'
    );


    echo json_encode(

        $data,

        JSON_UNESCAPED_UNICODE |
        JSON_PRETTY_PRINT

    );


    exit;

}



$beers = $data['beers'];

$isLive = $data['live'];

$venueLogo = $data['venueLogo'];



$grid =
    getGridSettings(
        count($beers)
    );


$columns = $grid['columns'];

$rows = $grid['rows'];



?>


<!doctype html>

<html lang="pl" translate="no">


<head>

<meta charset="utf-8">

<meta http-equiv="Content-Language" content="pl">

<meta name="google" content="notranslate">


<meta name="viewport" content="width=device-width, initial-scale=1">


<title>
Lamus TV
</title>



<link rel="stylesheet" href="style.css">


</head>



<body>


<main class="grid"

    style="
        --columns:<?= $columns ?>;
        --rows:<?= $rows ?>;
    ">



<?php foreach($beers as $beer): ?>



<div class="card">



    
    <div class="top">



        <div class="tap">


            <?= htmlspecialchars($beer['tap']) ?>


        </div>


        <div class="names">

            <div class="brewery">


                <?= htmlspecialchars($beer['brewery']) ?>


            </div>




            <div class="beer">


                <?= htmlspecialchars($beer['beer']) ?>


            </div>
        </div>

        <div class="brewery-logo">
            <?php if(!empty($beer['logo'])): ?>
                <img
                    src="<?= htmlspecialchars($beer['logo']) ?>"
                    alt=""
                >
            <?php endif; ?>
        </div>
    </div>


    <div class="bottom">



        <div class="meta">

            <?php if(!empty($beer['style'])): ?>

                <span class="beer-style">
                    <?= htmlspecialchars($beer['style']) ?>
                </span>

            <?php endif; ?>

            <?php if(!empty($beer['blg'])): ?>


                <span>
                    BLG <?= htmlspecialchars($beer['blg']) ?>°
                </span>


            <?php endif; ?>

            <?php if(!empty($beer['abv'])): ?>


                <span>
                    ALK <?= htmlspecialchars($beer['abv']) ?>%
                </span>


            <?php endif; ?>

        </div>





        <div class="prices">



            <?php foreach($beer['sizes'] as $size): ?>


                <div class="price">


                    <?= htmlspecialchars($size['size']) ?>l

                    <?= htmlspecialchars($size['price']) ?> zł


                </div>



            <?php endforeach; ?>



        </div>



    </div>




</div>




<?php endforeach; ?>



</main>


<header class="header">


    <div class="logo">


        <?php if(!empty($venueLogo)): ?>


            <img
                src="<?= htmlspecialchars($venueLogo) ?>"
                alt="Logo"
            >


        <?php else: ?>


            🍺 Lamus


        <?php endif; ?>


    </div>




    <div class="header-right">


        <span class="status"
              style="color:<?= $isLive ? '#00ff66' : '#ff9900' ?>">

            <?= $isLive ? 'LIVE' : 'CACHE' ?>

        </span>



        <span class="clock">


            <span class="clock-time">

                <?= date('H:i:s') ?>

            </span>


        </span>


    </div>


</header>





<script src="app.js"></script>



</body>


</html>
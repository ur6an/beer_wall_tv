<?php

declare(strict_types=1);


date_default_timezone_set('Europe/Warsaw');


const URL = 'https://lamus.ontap.pl';

const CACHE_FILE = __DIR__ . '/cache.json';





// =================================================
// LOGO LOKALU
// =================================================

function getVenueLogo(string $html): string
{
    libxml_use_internal_errors(true);


    $dom = new DOMDocument();


    @$dom->loadHTML(
        '<?xml encoding="UTF-8">' . $html
    );


    $xpath = new DOMXPath($dom);



    $logoNode = $xpath->query(
        "//img[contains(@alt,' Logo') and contains(@src,'download/multitap')]"
    );


    if($logoNode->length){


        $src = trim(
            $logoNode->item(0)->getAttribute('src')
        );



        if(str_starts_with($src,'//')){

            $src='https:' . $src;

        }
        elseif(str_starts_with($src,'/')){

            $src='https://ontap.pl'.$src;

        }
        elseif(!str_starts_with($src,'http')){

            $src='https://ontap.pl/'.$src;

        }



        return getLocalLogo($src);

    }


    return '';

}





// =================================================
// CACHE LOGO
// =================================================

function getLocalLogo(string $url): string
{

    if(!$url){

        return '';

    }


    $filename =
        basename(
            parse_url($url, PHP_URL_PATH)
        );



    $dir =
        __DIR__.'/cache/logos/';



    if(!is_dir($dir)){

        mkdir(
            $dir,
            0755,
            true
        );

    }



    $localFile =
        $dir.$filename;



    if(!file_exists($localFile)){


        $data =
            @file_get_contents($url);



        if($data !== false){

            file_put_contents(
                $localFile,
                $data
            );

        }

    }



    if(file_exists($localFile)){


        return 'cache/logos/'.$filename;

    }



    return '';

}





// =================================================
// CACHE DANYCH
// =================================================

function saveCache(array $data): void
{

    file_put_contents(

        CACHE_FILE,

        json_encode(

            [
                'time'=>time(),

                'beers'=>$data
            ],

            JSON_UNESCAPED_UNICODE |
            JSON_PRETTY_PRINT

        ),

        LOCK_EX

    );

}





function loadCache(): ?array
{

    if(!file_exists(CACHE_FILE)){

        return null;

    }



    $json =
        file_get_contents(
            CACHE_FILE
        );



    if($json === false){

        return null;

    }



    $data =
        json_decode(
            $json,
            true
        );



    if(
        !is_array($data) ||
        !isset($data['beers'])
    ){

        return null;

    }



    return $data;

}





// =================================================
// POBIERANIE STRONY
// =================================================

function getPage(string $url): ?string
{

    $curl =
        curl_init();



    curl_setopt_array(

        $curl,

        [

            CURLOPT_URL=>$url,

            CURLOPT_RETURNTRANSFER=>true,

            CURLOPT_FOLLOWLOCATION=>true,

            CURLOPT_TIMEOUT=>10,

            CURLOPT_CONNECTTIMEOUT=>5,

            CURLOPT_USERAGENT=>'Lamus-TV/1.0'

        ]

    );



    $html =
        curl_exec($curl);



    if($html === false){

        curl_close($curl);

        return null;

    }



    curl_close($curl);



    return $html;

}





// =================================================
// CZYSZCZENIE TEKSTU
// =================================================

function clean(string $text): string
{

    $text =
        html_entity_decode(

            $text,

            ENT_QUOTES | ENT_HTML5,

            'UTF-8'

        );



    $text =
        preg_replace(

            '/\s+/u',

            ' ',

            $text

        );



    return trim($text);

}





// =================================================
// PARSER PIW
// =================================================

function parseCards(string $html): array
{

    libxml_use_internal_errors(true);



    $dom =
        new DOMDocument();



    @$dom->loadHTML(
        '<?xml encoding="UTF-8">'.$html
    );



    $xpath =
        new DOMXPath($dom);



    $nodes =
        $xpath->query(

            "//div[contains(concat(' ',normalize-space(@class),' '),' panel-default ')]"

        );



    $beers=[];



    foreach($nodes as $card){


        $tap='';



        $tapNode =
            $xpath->query(

                ".//span[contains(@class,'label-primary')]",

                $card

            );



        if($tapNode->length){

            $tap =
                trim(
                    $tapNode->item(0)->textContent
                );

        }




        if($tap===''){

            continue;

        }



        $brewery='';



        $breweryNode =
            $xpath->query(

                ".//b[contains(@class,'brewery')]",

                $card

            );



        if($breweryNode->length){

            $brewery =
                clean(
                    $breweryNode->item(0)->textContent
                );


            // Usuń słowo "Brewery" z końca nazwy
            $brewery = preg_replace('/\s*Brewery\s*$/i', '', $brewery);
        }





        $bodyText =
            clean(
                $card->textContent
            );



        $blg='';

        $abv='';



        if(
            preg_match(
                '/(\d+)\s*°\s*(?:[·\.]\s*)?(\d+(?:[,.]\d+)?)\s*%/u',
                $bodyText,
                $m
            )
        ){

            $blg=$m[1];

            $abv=$m[2];

        }
        elseif(
            preg_match(
                '/(\d+(?:[,.]\d+)?)\s*%/u',
                $bodyText,
                $m
            )
        ){

            $abv=$m[1];

        }



        // -----------------------------
// NAZWA PIWA
// -----------------------------

$beer = '';

$h4Node = $xpath->query(
    ".//h4[contains(@class,'cml_shadow')]",
    $card
);


if ($h4Node->length) {


    $span = $xpath->query(
        ".//span",
        $h4Node->item(0)
    );


    if ($span->length) {


        $html =
            $dom->saveHTML(
                $span->item(0)
            );


        // usuwamy browar
        $html =
            preg_replace(
                '/<b[^>]*class="brewery"[^>]*>.*?<\/b>/is',
                '',
                $html
            );


        // usuwamy obrazki flag
        $html =
            preg_replace(
                '/<img[^>]*>/i',
                '',
                $html
            );


        // tekst po usunięciu HTML
        $text =
            strip_tags($html);


        $lines =
            preg_split(
                '/\R/u',
                $text
            );


        foreach($lines as $line){


            $line = clean($line);


            if($line !== ''){


                $beer = $line;

                break;

            }

        }

    }

}

        $style='';



        $styleNode =
            $xpath->query(

                ".//span[contains(@class,'cml_shadow')]//b",

                $card

            );



        if($styleNode->length){

            $style =
                clean(
                    $styleNode->item(0)->textContent
                );

        }





        $sizes=[];



        $footer =
            $xpath->query(

                ".//div[contains(@class,'panel-footer')]",

                $card

            );



        if($footer->length){


            preg_match_all(

                '/(\d+(?:\.\d+)?)l\s*:\s*(\d+)zł/u',

                clean($footer->item(0)->textContent),

                $matches,

                PREG_SET_ORDER

            );



            foreach($matches as $m){


                $sizes[]=[

                    'size'=>$m[1],

                    'price'=>$m[2]

                ];

            }

        }





        $logo='';



        $logoNode =
            $xpath->query(

                ".//div[contains(@class,'beer_brewery_logo')]//img",

                $card

            );



        if($logoNode->length){


            $logo =
                trim(
                    $logoNode->item(0)->getAttribute('src')
                );



            if(str_starts_with($logo,'//')){

                $logo='https:'.$logo;

            }



            $logo =
                getLocalLogo($logo);

        }





        $beers[]=[


            'tap'=>$tap,

            'brewery'=>$brewery,

            'logo'=>$logo,

            'beer'=>$beer,

            'style'=>$style,

            'blg'=>$blg,

            'abv'=>$abv,

            'sizes'=>$sizes


        ];


    }



    return $beers;

}





// =================================================
// GŁÓWNE POBRANIE DANYCH
// =================================================

function getBeers(): array
{

    $beers=[];

    $isLive=false;

    $venueLogo='';



    $html =
        getPage(URL);



    if($html !== null){


        $venueLogo =
            getVenueLogo($html);



        $newBeers =
            parseCards($html);



        if(!empty($newBeers)){


            $beers=$newBeers;


            saveCache($beers);


            $isLive=true;


        }

    }




    if(!$isLive){


        $cache =
            loadCache();



        if($cache !== null){

            $beers =
                $cache['beers'];

        }

    }



    return [

        'time'=>date('H:i:s'),

        'live'=>$isLive,

        'venueLogo'=>$venueLogo,

        'beers'=>$beers

    ];

}





// =================================================
// UKŁAD TV
// =================================================

function getGridSettings(int $count): array
{

    if($count <= 6){

        $columns=1;

    }
    elseif($count <= 12){

        $columns=2;

    }
    elseif($count <= 18){

        $columns=3;

    }
    else{

        $columns=4;

    }



    return [

        'columns'=>$columns,

        'rows'=>ceil($count/$columns)

    ];

}
function getBeerColor(style)
{

    if(!style){
        return '#ffcc00';
    }


    style = style.toLowerCase();


    const colors = {


        'ipa':'#ff8800',
        'dipa':'#ff5500',
        'double ipa':'#ff5500',
        'neipa':'#ff9900',


        'stout':'#6b3e1e',
        'porter':'#4b2a18',


        'lager':'#f2c200',
        'pils':'#ffd633',
        'pilsner':'#ffd633',


        'apa':'#ff9900',
        'pale ale':'#ffad33',


        'sour':'#ff4fa3',
        'berliner':'#ff66aa',


        'weizen':'#e8b44d',
        'wheat':'#e8b44d',


        'belgian':'#cc3333'

    };



    for(const key in colors){

        if(style.includes(key)){

            return colors[key];

        }

    }


    return '#ffcc00';

}

async function refreshBeers()
{
    try {

        const response = await fetch('index.php?api=1');

        const data = await response.json();


        updateClock(data.time);

        updateStatus(data.live);

        updateCards(data.beers);


    }
    catch(error){

        console.log(
            'Błąd odświeżania',
            error
        );

    }
}





function updateClock(time)
{
    const clock = document.querySelector('.clock-time');


    if(clock){

        clock.textContent = time;

    }
}





function updateStatus(live)
{
    const status = document.querySelector('.status');


    if(status){

        status.textContent =
            live
            ? 'LIVE'
            : 'CACHE';



        status.style.color =
            live
            ? '#00ff66'
            : '#ff9900';

    }
}







function updateCards(beers)
{

    const grid = document.querySelector('.grid');


    if(!grid){

        return;

    }


    /*
        pierwsze uruchomienie
        albo zmiana ilości kranów
    */

    if(
        grid.children.length !== beers.length ||
        !grid.classList.contains(
            'layout-' + beers.length
        )
    ){

        renderCards(beers);

        return;

    }



    /*
        aktualizacja istniejących kart
    */

    beers.forEach((beer,index)=>{


        const card =
            grid.children[index];


        if(!card){
            return;
        }



        card.style.setProperty(
            '--beer-color',
            getBeerColor(beer.style)
        );



        const tap =
            card.querySelector('.tap');

        if(tap){

            tap.textContent =
                beer.tap;

        }



        const brewery =
            card.querySelector('.brewery');

        if(brewery){

            brewery.textContent =
                beer.brewery;

        }



        const beerName =
            card.querySelector('.beer');

        if(beerName){

            beerName.textContent =
                beer.beer;

        }


        const logoContainer =
    card.querySelector('.brewery-logo');

if (logoContainer) {

    if (beer.logo) {

        let img = logoContainer.querySelector('img');

        if (!img) {

            img = document.createElement('img');
            img.alt = '';
            img.onerror = () => img.style.display = 'none';

            logoContainer.appendChild(img);
        }

        if (img.getAttribute('src') !== beer.logo) {

            img.src = beer.logo;
            img.style.display = '';

        }

    } else {

        logoContainer.innerHTML = '';

    }

}



        const style =
            card.querySelector('.beer-style');

        if(style){

            style.textContent =
                beer.style || '';

        }



        const meta =
            card.querySelectorAll(
                '.meta span:not(.beer-style)'
            );


        if(meta[0]){

            meta[0].textContent =
                beer.blg
                ? `BLG ${beer.blg}°`
                : '';

        }


        if(meta[1]){

            meta[1].textContent =
                beer.abv
                ? `ALK ${beer.abv}%`
                : '';

        }



        updatePrices(
            card,
            beer.sizes
        );



    });


}

function renderCards(beers)
{

    const grid =
        document.querySelector('.grid');


    grid.className =
        'grid layout-' + beers.length;



    grid.innerHTML =
        beers.map(beer => `


<div class="card"
style="--beer-color:${getBeerColor(beer.style)};">



    <div class="top">


        <div class="tap">

            ${escapeHtml(beer.tap)}

        </div>



        <div class="names">


            <div class="brewery">

                ${escapeHtml(beer.brewery)}

            </div>



            <div class="beer">

                ${escapeHtml(beer.beer)}

            </div>


        </div>




        <div class="brewery-logo">


            ${
                beer.logo
                ?
                `
                <img
                    src="${beer.logo}"
                    alt=""
                    onerror="this.style.display='none'"
                >
                `
                :
                ''
            }


        </div>



    </div>





    <div class="bottom">



        <div class="meta">



            ${
                beer.style
                ?
                `
                <span class="beer-style">
                    ${escapeHtml(beer.style)}
                </span>
                `
                :
                ''
            }




            ${
                beer.blg
                ?
                `
                <span>
                    BLG ${escapeHtml(beer.blg)}°
                </span>
                `
                :
                ''
            }





            ${
                beer.abv
                ?
                `
                <span>
                    ALK ${escapeHtml(beer.abv)}%
                </span>
                `
                :
                ''
            }



        </div>




        <div class="prices">

            ${
                (beer.sizes || [])
                .map(size => `

                    <div class="price">

                        ${escapeHtml(size.size)}l

                        ${escapeHtml(size.price)} zł

                    </div>

                `)
                .join('')
            }


        </div>




    </div>



</div>



        `)
        .join('');

}

function updatePrices(card,sizes)
{

    const prices =
        card.querySelector('.prices');


    if(!prices){
        return;
    }


    prices.innerHTML =
        (sizes || [])
        .map(size=>`

        <div class="price">
            ${size.size}l
            ${size.price} zł
        </div>

        `)
        .join('');

}

function escapeHtml(text)
{

    return String(text ?? '')
        .replace(/&/g,'&amp;')
        .replace(/</g,'&lt;')
        .replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;')
        .replace(/'/g,'&#039;');

}




// pierwsze pobranie

refreshBeers();




// odświeżanie danych

setInterval(
    refreshBeers,
    120000
);